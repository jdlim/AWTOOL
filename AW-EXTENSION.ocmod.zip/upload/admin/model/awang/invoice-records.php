/***** BEGIN OF INVOICE RECORD MODULE ********/
	function invoicerec( $filename ) {
		// we use our own error handler
		global $registry;
		$registry = $this->registry;
		set_error_handler('error_handler_for_rlmexport',E_ALL);
		register_shutdown_function('fatal_error_shutdown_handler_for_rlmexport');

		try {
			$database =& $this->db;
			$this->session->data['export_nochange'] = 1;

			$emplist=$this->loadEmployee($database);			
			
			// we use the PHPExcel package from http://phpexcel.codeplex.com/
			$cwd = getcwd();
			chdir( DIR_SYSTEM.'PHPExcel' );
			require_once( 'Classes/PHPExcel.php' );
			chdir( $cwd );
			// parse uploaded spreadsheet file
			$inputFileType = PHPExcel_IOFactory::identify($filename);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objReader->setReadDataOnly(true);
			$reader = $objReader->load($filename);
			
			// read the various worksheets and load them to the database
			$ok = $this->validateInvoice( $reader );
			if (!$ok) {
				return FALSE;
			}
			$this->clearCache();
			$this->session->data['export_nochange'] = 0;
			
			$ok = $this->uploadInvoice( $reader, $emplist, $database );
			if (!$ok) {
				return FALSE;
			}
			return $ok;
			
		} catch (Exception $e) {
			$errstr = $e->getMessage();
			$errline = $e->getLine();
			$errfile = $e->getFile();
			$errno = $e->getCode();
			$this->session->data['export_error'] = array( 'errstr'=>$errstr, 'errno'=>$errno, 'errfile'=>$errfile, 'errline'=>$errline );
			if ($this->config->get('config_error_log')) {
				$this->log->write('PHP ' . get_class($e) . ':  ' . $errstr . ' in ' . $errfile . ' on line ' . $errline);
			}
			return FALSE;
		}
	}

	function validateInvoice( &$reader ) 
	{
		$sheetNames = $reader->getSheetNames();
		if ($sheetNames[0] != 'AR Invoice Register') {
			 error_log(date('Y-m-d H:i:s - ', time()).$this->language->get( 'error_sheet_count' )."\n",3,DIR_LOGS."error.txt");
			return FALSE;					
		}
		return TRUE;
	}

	function uploadInvoice( &$reader, &$emplist, &$database ) {

		$data = $reader->getSheet(0);
		$invoices = array();
		$invoice = array();
		$name = array();
		$invcol = $this->invcol();
		$isFirstRow = TRUE;
		$isHeaderRow = TRUE;
		$i = 0;
		$k = $data->getHighestRow();
		for ($i=0; $i<$k; $i+=1) {
			if ($isFirstRow) {
				$isFirstRow = FALSE;
				continue;
			}
			if ($isHeaderRow) {
				$isHeaderRow = FALSE;
				continue;
			}						
			$customer_id = "'".$this->getCell($data, $i, $invcol['CustID'])."'";
// GOD
//echo $customer_id."  [".$emplist['PERS760']."] <br> ";
//echo $customer_id."  [".$emplist[str_replace("'","",$customer_id)]."] <br> ";
			if (array_key_exists(str_replace("'","",$customer_id),$emplist)) {
				$invoices[$i]['customer_id']=$emplist[str_replace("'","",$customer_id)];
			} else {
				continue;
			}
			
			$invoices[$i]['customer_invoice_id']= 'NULL';
			$invoices[$i]['invoice_id']=$this->getCell($data, $i, $invcol['InvoiceNum']);
			$invoices[$i]['invoice_date']="STR_TO_DATE('".$this->getCell($data, $i, $invcol['InvoiceDate'])."', '%m/%d/%Y')";
			$invoices[$i]['order_num']=$this->getCell($data, $i, $invcol['OrderID']);
			$invoices[$i]['cust_po']=$this->getCell($data, $i, $invcol['CustPO']);
			$invoices[$i]['subdivname']=$this->getCell($data, $i, $invcol['SubDivName']);
			$invoices[$i]['units']=$this->getCell($data, $i, $invcol['Units']);
			$invoices[$i]['std_amount']=$this->getCell($data, $i, $invcol['StdAmount']);
			$invoices[$i]['tax_amount']=$this->getCell($data, $i, $invcol['TaxAmount']);
			$invoices[$i]['ar_amount']=$this->getCell($data, $i, $invcol['ARAmount']);
			$invoices[$i]['date_added']='NOW()';
		}
		return $this->storeInvoice( $database, $invoices );
	}
	
	function invcol(){
		return array ('InvoiceNum'=>1,'InvoiceDate'=>2,'CustID'=>7,'OrderID'=>10,'CustPO'=>11,'SubDivName'=>18,'Units'=>29,'StdAmount'=>32,'TaxAmount'=>36,'ARAmount'=>40);
	}	
	
	function storeInvoice( &$database, &$invoices ) 
	{
		$sql = "";
		// start transaction, 
		$sql = "START TRANSACTION;\n";
		// disable all accounts
		$sql .= "SET SQL_SAFE_UPDATES=0;\n";
		$this->multiquery( $database, $sql );
		$sql='';
		$database->query($sql);
		$database->query("COMMIT;");
		//keep track of new products and updated ones
		$newones = 0;
		$updateinvoice = 0;
		$firstone = $database->getLastId();

		foreach ($invoices as $invoice) {
			$customer_invoice_id = $database->escape($invoice['customer_invoice_id']);
			$invoice_id = $invoice['invoice_id'];
//			$invoice_date = $database->escape($invoice['invoice_date']);
			$invoice_date = $invoice['invoice_date'];
			$customer_id = $invoice['customer_id'];
			$order_num = $invoice['order_num'];
			$cust_po = "'".$invoice['cust_po']."'";
			$subdivname = "'".$database->escape($invoice['subdivname'])."'";
			$units = $database->escape($invoice['units']);
			$std_amount = "'".$database->escape($invoice['std_amount'])."'";
			$tax_amount = "'".$database->escape($invoice['tax_amount'])."'";
			$ar_amount = "'".$database->escape($invoice['ar_amount'])."'";
			$date_added = $database->escape($invoice['date_added']);

			$lastonestart = $database->getLastId();
			$sql = '';
			$sql  = "INSERT INTO ".DB_PREFIX."customer_invoice (customer_invoice_id,invoice_id,invoice_date,customer_id,order_num,cust_po,subdivname,units,std_amount,tax_amount,ar_amount,date_added)";
			$sql .= " VALUES ";
			$sql .= "($customer_invoice_id,$invoice_id,$invoice_date,$customer_id,$order_num,$cust_po,$subdivname,$units,$std_amount,$tax_amount,$ar_amount,$date_added)";
			$sql .= " ON DUPLICATE KEY UPDATE ";
			$sql .= "invoice_id=VALUES(invoice_id),invoice_date=VALUES(invoice_date),customer_id=VALUES(customer_id),order_num=VALUES(order_num),cust_po=VALUES(cust_po),subdivname=VALUES(subdivname),units=VALUES(units),std_amount=VALUES(std_amount),tax_amount=VALUES(tax_amount),ar_amount=VALUES(ar_amount),date_added=VALUES(date_added);";
 			$database->query($sql);
			$lastoneend = $database->getLastId();
			$updateinvoice++;
		}
		// final commit
		$database->query("COMMIT;");
		// Store the status to be displayed on page
		$this->session->data['uploadstatus'] = "SUCCESS: $updateinvoice invoice records were updated";

		return TRUE;
	}

/***** END OF INVOICE MODULE ********/

/*
DROP TABLE oc_customer_invoice;

CREATE TABLE oc_customer_invoice (
customer_invoice_id	INT(11) AUTO_INCREMENT PRIMARY KEY,
invoice_id INT(11) UNIQUE KEY,
invoice_date DATE,
cust_id INT(11),
order_num INT(11),
cust_po varchar(64),
subdivname	VARCHAR(64),
units	INT(11),
std_amount	DECIMAL(15,2),
tax_amount  DECIMAL(15,2),
ar_amount   DECIMAL(15,2),
date_added  DATE   );
*/
