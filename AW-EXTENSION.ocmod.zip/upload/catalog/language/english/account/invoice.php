<?php
// Heading
$_['heading_title']      = 'Your Invoices';

// Column
$_['column_date_added']  = 'Date Added';
$_['column_description'] = 'Description';
$_['column_units'] 		 = 'Units';
$_['column_amount']      = 'Amount (%s)';

// Text
$_['text_account']       = 'Account';
$_['text_invoice']   = 'Your Invoices';
$_['text_total']         = 'Your current invoices amount is:';
$_['text_empty']         = 'You do not have any invoices!';